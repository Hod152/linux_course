#! /bin/bash
whoami
